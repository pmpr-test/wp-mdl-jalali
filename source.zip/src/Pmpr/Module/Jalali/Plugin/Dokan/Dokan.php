<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             693021d4a3670             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Jalali\Plugin\Dokan; use Pmpr\Module\Jalali\Container; class Dokan extends Container { public function mameiwsayuyquoeq() { Checkout::symcgieuakksimmu(); SellerDashboard::symcgieuakksimmu(); } }
