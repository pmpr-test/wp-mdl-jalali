<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             693401d1e246c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Jalali\Plugin\Dokan; use Pmpr\Module\Jalali\Container; class Dokan extends Container { public function mameiwsayuyquoeq() { Checkout::symcgieuakksimmu(); SellerDashboard::symcgieuakksimmu(); } }
