<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             692d50cd9bc89             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Jalali\Plugin\Dokan; use Pmpr\Module\Jalali\Container; class Dokan extends Container { public function mameiwsayuyquoeq() { Checkout::symcgieuakksimmu(); SellerDashboard::symcgieuakksimmu(); } }
