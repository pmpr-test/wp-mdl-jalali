<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67053143def1d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Jalali\Plugin; use Pmpr\Module\Jalali\Container; class Plugin extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\154\x75\x67\x69\x6e\x73\x5f\154\157\x61\144\x65\144", [$this, "\x69\x63\x77\x63\x67\x6d\x63\157\x69\155\x71\x65\x69\147\x79\145"]); } public function icwcgmcoimqeigye() { if ($this->caokeucsksukesyo()->wikusamwomuogoau()->ggocakcisguuokai()) { Woocommerce::symcgieuakksimmu(); } } }
