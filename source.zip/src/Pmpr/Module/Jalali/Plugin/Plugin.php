<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8eb69fb2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Jalali\Plugin; class Plugin extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\154\x75\147\151\x6e\x73\137\x6c\157\x61\x64\x65\144", [$this, "\x69\143\167\143\x67\155\143\x6f\151\155\x71\x65\151\147\x79\145"]); } public function icwcgmcoimqeigye() { if (!$this->caokeucsksukesyo()->wikusamwomuogoau()->ggocakcisguuokai()) { goto asmecuqiyyswueqe; } Woocommerce::symcgieuakksimmu(); asmecuqiyyswueqe: } }
