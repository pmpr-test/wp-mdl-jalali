<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e79688f4e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Jalali\Plugin; class Plugin extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\154\165\x67\x69\x6e\163\137\x6c\x6f\x61\144\145\144", [$this, "\151\x63\x77\x63\x67\x6d\143\157\x69\155\161\145\x69\147\171\145"]); } public function icwcgmcoimqeigye() { if (!$this->caokeucsksukesyo()->wikusamwomuogoau()->ggocakcisguuokai()) { goto asmecuqiyyswueqe; } Woocommerce::symcgieuakksimmu(); asmecuqiyyswueqe: } }
