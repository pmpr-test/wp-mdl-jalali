<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67051768bea73             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Jalali\Plugin; class Plugin extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\154\x75\147\151\x6e\163\137\154\157\x61\x64\x65\x64", [$this, "\151\143\167\x63\x67\x6d\x63\x6f\151\155\161\145\x69\x67\x79\145"]); } public function icwcgmcoimqeigye() { if (!$this->caokeucsksukesyo()->wikusamwomuogoau()->ggocakcisguuokai()) { goto iwekmyyccgiyuecc; } Woocommerce::symcgieuakksimmu(); iwekmyyccgiyuecc: } }
