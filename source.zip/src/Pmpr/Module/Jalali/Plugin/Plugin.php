<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f43aec6e51b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Jalali\Plugin; class Plugin extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\154\x75\147\151\x6e\163\137\154\157\141\x64\145\x64", [$this, "\x69\x63\x77\x63\147\155\143\x6f\151\x6d\x71\x65\151\x67\x79\x65"]); } public function icwcgmcoimqeigye() { if (!$this->caokeucsksukesyo()->wikusamwomuogoau()->ggocakcisguuokai()) { goto ikqqskkqqwmwssoo; } Woocommerce::symcgieuakksimmu(); ikqqskkqqwmwssoo: } }
