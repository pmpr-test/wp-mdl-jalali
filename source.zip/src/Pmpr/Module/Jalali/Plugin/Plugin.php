<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f3b7a529fb1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Jalali\Plugin; class Plugin extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\154\165\147\151\156\163\137\x6c\x6f\141\x64\145\x64", [$this, "\x69\143\x77\143\147\155\x63\157\151\155\161\x65\x69\x67\171\x65"]); } public function icwcgmcoimqeigye() { if (!$this->caokeucsksukesyo()->wikusamwomuogoau()->ggocakcisguuokai()) { goto iwekmyyccgiyuecc; } Woocommerce::symcgieuakksimmu(); iwekmyyccgiyuecc: } }
