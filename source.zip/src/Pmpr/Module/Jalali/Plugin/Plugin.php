<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec7c0ed9a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Jalali\Plugin; class Plugin extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\x6c\165\x67\x69\x6e\x73\x5f\x6c\157\x61\144\x65\144", [$this, "\151\143\x77\143\x67\x6d\143\157\151\x6d\161\145\151\x67\x79\x65"]); } public function icwcgmcoimqeigye() { if (!$this->caokeucsksukesyo()->wikusamwomuogoau()->ggocakcisguuokai()) { goto asmecuqiyyswueqe; } Woocommerce::symcgieuakksimmu(); asmecuqiyyswueqe: } }
