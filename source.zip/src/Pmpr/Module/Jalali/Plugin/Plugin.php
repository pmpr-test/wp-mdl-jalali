<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f3b72c6b379             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Jalali\Plugin; class Plugin extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\x6c\165\147\x69\156\163\x5f\x6c\157\x61\144\x65\144", [$this, "\151\x63\x77\143\x67\x6d\x63\157\151\155\161\145\x69\x67\171\x65"]); } public function icwcgmcoimqeigye() { if (!$this->caokeucsksukesyo()->wikusamwomuogoau()->ggocakcisguuokai()) { goto iwekmyyccgiyuecc; } Woocommerce::symcgieuakksimmu(); iwekmyyccgiyuecc: } }
