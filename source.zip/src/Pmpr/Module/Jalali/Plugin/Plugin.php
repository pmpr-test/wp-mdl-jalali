<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f4310291d30             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Jalali\Plugin; class Plugin extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\x6c\x75\x67\x69\156\163\x5f\x6c\x6f\141\144\145\144", [$this, "\151\143\167\x63\x67\x6d\x63\x6f\151\155\x71\145\151\x67\171\x65"]); } public function icwcgmcoimqeigye() { if (!$this->caokeucsksukesyo()->wikusamwomuogoau()->ggocakcisguuokai()) { goto ikqqskkqqwmwssoo; } Woocommerce::symcgieuakksimmu(); ikqqskkqqwmwssoo: } }
