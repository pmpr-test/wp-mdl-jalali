<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67b82b6d2a9a1             |
    |_______________________________________|
*/
 use Pmpr\Module\Jalali\Jalali; Jalali::symcgieuakksimmu();
