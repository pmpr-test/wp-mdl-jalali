<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6746eb8635eb7             |
    |_______________________________________|
*/
 use Pmpr\Module\Jalali\Jalali; Jalali::symcgieuakksimmu();
